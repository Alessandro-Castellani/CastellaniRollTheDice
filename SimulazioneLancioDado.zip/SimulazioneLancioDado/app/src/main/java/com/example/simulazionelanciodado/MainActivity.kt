package com.example.simulazionelanciodado

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private lateinit var txtNumber: TextView
    private lateinit var imgDice: ImageView
    private lateinit var btnRoll: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        Log.d(TAG, "Layout caricato")


        txtNumber = findViewById(R.id.idTextNumber)
        imgDice = findViewById(R.id.idDice)
        btnRoll = findViewById(R.id.idRoll)

        btnRoll.setOnClickListener {
            Toast.makeText(applicationContext, "Gioca con noi!", Toast.LENGTH_LONG).show()
            rollDice()
            Log.d(TAG, "click del bottone")
        }
    }

    private fun rollDice() {
        val diceRoll = (1..6).random()
        txtNumber.text = diceRoll.toString()

        val diceImage = when (diceRoll) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }

        imgDice.setImageResource(diceImage)
    }

    fun showMessage(view: View) {
        Log.d(TAG, "show")
        Toast.makeText(applicationContext, "Try again!", Toast.LENGTH_LONG).show()
    }
}